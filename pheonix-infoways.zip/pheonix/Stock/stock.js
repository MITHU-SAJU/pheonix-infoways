
function addField() {
    const container = document.getElementById('warehouseStockFields');
    const newRow = document.createElement('div');
    newRow.classList.add('row', 'warehouse-entry');
  
    newRow.innerHTML = `
      <select class="warehouse-select" name="warehouse[]">
        <option value="">-- Select Warehouse --</option>
        <option value="Warehouse A">Warehouse A</option>
        <option value="Warehouse B">Warehouse B</option>
        <option value="Warehouse C">Warehouse C</option>
      </select>
      <input type="number" class="stock-input" placeholder="Stock" name="stock[]">
      <button type="button" class="add-btn" onclick="addField()"><i class="fas fa-plus"></i></button>
      <button type="button" class="remove-btn" onclick="this.parentElement.remove()">-</button>
    `;
  
    container.appendChild(newRow);
  }
  