
document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.getElementById('toggleBtn');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');

    toggleBtn.addEventListener('click', function () {
      sidebar.classList.toggle('collapsed');
      mainContent.classList.toggle('expanded');
    });
  });



  const searchInput = document.getElementById('searchInput');
const brandFilter = document.getElementById('brandFilter');
const table = document.getElementById('productTable');
const autocompleteList = document.getElementById('autocomplete-list');

function filterTable() {
  const filterText = searchInput.value.toLowerCase();
  const selectedBrand = brandFilter.value.toLowerCase();

  const rows = table.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const brand = row.cells[2].textContent.toLowerCase();
    const model = row.cells[3].textContent.toLowerCase();

    const matchSearch = brand.includes(filterText) || model.includes(filterText);
    const matchBrand = selectedBrand === '' || brand === selectedBrand;

    if (matchSearch && matchBrand) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
}

// Autocomplete logic
function showAutocompleteSuggestions() {
  const inputVal = searchInput.value.toLowerCase();
  autocompleteList.innerHTML = '';
  if (!inputVal) return;

  const suggestions = new Set();

  const rows = table.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const brand = row.cells[2].textContent.toLowerCase();
    const model = row.cells[3].textContent.toLowerCase();
    if (brand.startsWith(inputVal)) suggestions.add(brand);
    if (model.startsWith(inputVal)) suggestions.add(model);
  });

  suggestions.forEach(s => {
    const div = document.createElement('div');
    div.textContent = s;
    div.onclick = () => {
      searchInput.value = s;
      autocompleteList.innerHTML = '';
      filterTable();
    };
    autocompleteList.appendChild(div);
  });
}

// Event Listeners
searchInput.addEventListener('keyup', () => {
  filterTable();
  showAutocompleteSuggestions();
});
brandFilter.addEventListener('change', filterTable);

// Click outside to close suggestions
document.addEventListener('click', (e) => {
  if (e.target !== searchInput) {
    autocompleteList.innerHTML = '';
  }
});


//for modal
function openModal() {
  document.getElementById('stockModal').style.display = 'flex';
}

function closeModal() {
  document.getElementById('stockModal').style.display = 'none';
}

// Close modal if clicking outside content
window.onclick = function(event) {
  const modal = document.getElementById('stockModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
}


//for bulk upload
const fileInput = document.getElementById("bulk-file");
const statusText = document.getElementById("upload-status");

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  // Show uploading status
  statusText.textContent = "Uploading...";

  const formData = new FormData();
  formData.append("file", file);

  try {
    const response = await fetch("/upload", {  // <-- Replace with your real endpoint
      method: "POST",
      body: formData,
    });

    if (response.ok) {
      statusText.textContent = "Upload successful ✅";
      statusText.style.color = "green";
    } else {
      statusText.textContent = "Upload failed ❌";
      statusText.style.color = "red";
    }
  } catch (err) {
    console.error(err);
    statusText.textContent = "Upload error ❌";
    statusText.style.color = "red";
  }
});

//add stock dynamicaalyy
// function addField() {
//   const container = document.getElementById('warehouseStockFields');
//   const newRow = document.createElement('div');
//   newRow.className = 'row';
//   newRow.innerHTML = `
//     <input type="text" placeholder="Warehouse" name="warehouse[]">
//     <input type="number" placeholder="Stock" name="stock[]">
//     <button type="button" class="add-btn" onclick="addField()">+</button>
//   `;
//   container.appendChild(newRow);
// }

function submitForm() {
  const product = document.getElementById('productSelect').value;
  const warehouses = document.getElementsByName('warehouse[]');
  const stocks = document.getElementsByName('stock[]');

  const stockData = [];
  for (let i = 0; i < warehouses.length; i++) {
    stockData.push({
      warehouse: warehouses[i].value,
      stock: stocks[i].value
    });
  }

  console.log({
    product,
    stockData
  });

  alert("Stock has been added successfully");
}

function filterOptions() {
  const input = document.getElementById('productSelect');
  const filter = input.value.toLowerCase();
  const options = document.querySelectorAll('#customOptions li');
  const dropdown = document.getElementById('customOptions');

  let hasVisible = false;
  options.forEach(option => {
    const text = option.textContent.toLowerCase();
    if (text.includes(filter)) {
      option.style.display = '';
      hasVisible = true;
    } else {
      option.style.display = 'none';
    }
  });

  dropdown.style.display = hasVisible ? 'block' : 'none';
}

function selectOption(elem) {
  document.getElementById('productSelect').value = elem.textContent;
  document.getElementById('customOptions').style.display = 'none';
}

const input = document.getElementById("tableSearchInput");
const productTableBody = document.getElementById("productTable").getElementsByTagName("tbody")[0];

input.addEventListener("input", function () {
  const searchTerm = this.value.toLowerCase();

  Array.from(productTableBody.rows).forEach(row => {
    const rowText = row.textContent.toLowerCase();
    row.style.display = rowText.includes(searchTerm) ? "" : "none";
  });
});




  const profileIcon = document.getElementById('profileIcon');
  const profileDropdown = document.getElementById('profileDropdown');

  profileIcon.addEventListener('click', () => {
    const isVisible = profileDropdown.style.display === 'block';
    profileDropdown.style.display = isVisible ? 'none' : 'block';
  });

  window.addEventListener('click', (e) => {
    if (!profileIcon.contains(e.target) && !profileDropdown.contains(e.target)) {
      profileDropdown.style.display = 'none';
    }
  });


  const logToggleBtn = document.getElementById('logToggleBtn');
  const logPanel = document.getElementById('logPanel');
  const closeLogBtn = document.getElementById('closeLogBtn');
  const logBadge = document.getElementById('logBadge');

  logToggleBtn.addEventListener('click', () => {
    logPanel.classList.toggle('show');
    logBadge.style.display = 'none'; // Hide badge after viewing
  });

  closeLogBtn.addEventListener('click', () => {
    logPanel.classList.remove('show');
  });

  document.addEventListener('DOMContentLoaded', () => {
    const profileIcon = document.getElementById('profileIcon');
    const profileDropdown = document.getElementById('profileDropdown');
  
    profileIcon.addEventListener('click', () => {
      const isVisible = profileDropdown.style.display === 'block';
      profileDropdown.style.display = isVisible ? 'none' : 'block';
    });
  
    window.addEventListener('click', (e) => {
      if (!profileIcon.contains(e.target) && !profileDropdown.contains(e.target)) {
        profileDropdown.style.display = 'none';
      }
    });
  });
 

 