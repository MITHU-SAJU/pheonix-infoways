
function addField() {
    const container = document.getElementById('warehouseStockFields');
    const newRow = document.createElement('div');
    newRow.classList.add('row', 'warehouse-entry');
  
    newRow.innerHTML = `
    <input type="text" class="stock-input" placeholder="Enter Warehouse" name="stock[]">
      <input type="number" class="stock-input" placeholder="Stock" name="stock[]">
      <button type="button" class="add-btn" onclick="addField()"><i class="fas fa-plus"></i></button>
      <button type="button" class="remove-btn" onclick="this.parentElement.remove()">-</button>
    `;
  
    container.appendChild(newRow);
  }
  