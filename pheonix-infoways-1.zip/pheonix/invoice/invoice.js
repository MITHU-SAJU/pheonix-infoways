window.addEventListener("DOMContentLoaded", () => {
    let products = [];
    let invoices = [];
  
    // Button References
    const addProductBtn = document.getElementById('addProductBtn');
    const generateInvoiceBtn = document.getElementById('generateInvoiceBtn');
  
    // Event Listeners
    addProductBtn.addEventListener('click', addProduct);
    generateInvoiceBtn.addEventListener('click', generateInvoice);
  
    // === Product Functions ===
    function addProduct() {
      const name = document.getElementById('productName').value.trim();
      const qty = parseInt(document.getElementById('productQty').value);
      const price = parseFloat(document.getElementById('productPrice').value);
  
      if (!name || isNaN(qty) || qty <= 0 || isNaN(price) || price < 0) {
        alert('❌ Please enter valid product details.');
        return;
      }
  
      products.push({ name, qty, price, total: qty * price });
      updateProductTable();
      clearProductFields();
      updateTotals();
    }
  
   function updateProductTable() {
  const tbody = document.querySelector('#productTable tbody');
  tbody.innerHTML = '';

  products.forEach((product, index) => {
    const row = document.createElement('tr');

    row.innerHTML = `
      <td>${index + 1}</td> <!-- S.NO -->
      <td>${product.name}</td>
      <td>${product.qty}</td>
      <td>₹${product.price.toFixed(2)}</td>
      <td>₹${product.total.toFixed(2)}</td>
      <td><button class="remove-btn" onclick="removeProduct(${index})">Remove</button></td>
    `;

    tbody.appendChild(row);
  });
}

    // Make removeProduct globally accessible
    window.removeProduct = function(index) {
      products.splice(index, 1);
      updateProductTable();
      updateTotals();
    };
  
    function clearProductFields() {
      document.getElementById('productName').value = '';
      document.getElementById('productQty').value = '';
      document.getElementById('productPrice').value = '';
    }
  
    function updateTotals() {
      const subtotal = products.reduce((sum, p) => sum + p.total, 0);
      const tax = +(subtotal * 0.18).toFixed(2);
      const grandTotal = +(subtotal + tax).toFixed(2);
  
      document.getElementById('subtotal').textContent = subtotal.toFixed(2);
      document.getElementById('tax').textContent = tax.toFixed(2);
      document.getElementById('grandTotal').textContent = grandTotal.toFixed(2);
    }
  
    // === Invoice Functions ===
    function generateInvoice() {
      const company = document.getElementById("companyName").value;
      const brand = document.getElementById("brand").value;
      const model = document.getElementById("model").value;
      const customer = document.getElementById("customer").value;
      const date = document.getElementById("date").value;
  
      const productRows = document.querySelectorAll("#productTable tbody tr");
      const products = [];
      let total = 0;
  
      productRows.forEach(row => {
        const name = row.children[0].textContent;
        const qty = parseInt(row.children[1].textContent);
        const unitPrice = parseFloat(row.children[2].textContent.replace("₹", ""));
        const rowTotal = qty * unitPrice;
        total += rowTotal;
  
        products.push({ name, qty, unitPrice, rowTotal });
      });
  
      const invoice = {
        company,
        brand,
        model,
        customer,
        date,
        products,
        total
      };
  
      let allInvoices = JSON.parse(localStorage.getItem("invoices")) || [];
      allInvoices.push(invoice);
      localStorage.setItem("invoices", JSON.stringify(allInvoices));
  
      window.location.href = "invoice-list.html";
    }
  
    // === Invoice List Page Handler ===
    const invoiceTable = document.querySelector("#invoiceTable tbody");
    if (invoiceTable) {
      const savedInvoices = JSON.parse(localStorage.getItem("invoices")) || [];
  
      savedInvoices.forEach((invoice, index) => {
        const tr = document.createElement("tr");
  
        tr.innerHTML = `
          <td>${index + 1}</td>
          <td>${invoice.company}</td>
          <td>${invoice.brand}</td>
          <td>${invoice.model}</td>
          <td>${invoice.customer}</td>
          <td>${invoice.date}</td>
          <td>
            ${invoice.products.map(p => `${p.name} (x${p.qty})`).join(", ")}
          </td>
          <td>₹${invoice.total.toFixed(2)}</td>
        `;
  
        invoiceTable.appendChild(tr);
      });
    }
  });
  